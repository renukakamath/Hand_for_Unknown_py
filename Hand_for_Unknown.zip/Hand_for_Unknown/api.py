from flask import Blueprint,request
from database import *
import demjson

api=Blueprint('api',__name__)

@api.route('/login/',methods=['get','post'])
def login():
	data={}
	username=request.args['username']
	password=request.args['password']
	q="select * from login where  username='%s' and password='%s'" %(username,password)
	res=select(q)
	if res:
		data['status']="success"
		data['data']=res
	else:
		data['status']="failed"
	return  demjson.encode(data)

@api.route('/register/',methods=['get','post'])
def register():
	data={}
	
	first_name = request.args['firstname']
	last_name = request.args['lastname']
	house = request.args['house']
	place = request.args['place']
	pincode = request.args['pincode']
	phone = request.args['phone']
	email = request.args['email']
	username = request.args['username']
	password = request.args['password']
	
	q = "insert into login values(null,'%s','%s','parent')" % (username,password)
	login_id = insert(q)
	q = "insert into parents values(null,'%s','%s','%s','%s','%s','%s','%s','%s')" % (login_id,first_name,last_name,house,place,pincode,phone,email)
	print(q)
	insert(q)
	data['status'] = 'success'
	return demjson.encode(data)

@api.route('/childregister/',methods=['get','post'])
def childregister():
	data={}
	
	name = request.args['name']
	gender = request.args['gender']
	dob = request.args['dob']
	logid = request.args['logid']
	
	q = "insert into child values(null,(select parent_id from parents where log_id='%s'),'%s','%s','%s')" % (logid,name,gender,dob)
	login_id = insert(q)
	
	data['status'] = 'success'
	data['method']="childregister"
	return demjson.encode(data)

@api.route('/viewchilds/',methods=['get','post'])
def viewchilds():
	data={}
	logid=request.args['logid']
	
	q="select * from child where parent_id=(select parent_id from parents where log_id='%s')" %(logid)
	res=select(q)
	print(res)
	if res:
		data['status']="success"
		data['data']=res
	else:
		data['status']="failed"
	data['method']="viewchilds"
	return  demjson.encode(data)



@api.route('/enquiry/',methods=['get','post'])
def enquiry():
	data={}
	
	enquirys = request.args['enquirys']
	logid = request.args['logid']
	
	q = "insert into enquiry values(null,(select parent_id from parents where log_id='%s'),'%s','pending',curdate())" % (logid,enquirys)
	login_id = insert(q)
	
	data['status'] ="success"
	data['method']="enquiry"
	return demjson.encode(data)

@api.route('/viewenquiry/',methods=['get','post'])
def viewenquiry():
	data={}
	logid=request.args['logid']
	
	q="select * from enquiry where parent_id=(select parent_id from parents where log_id='%s')" %(logid)
	res=select(q)
	print(res)
	if res:
		data['status']="success"
		data['data']=res
	else:
		data['status']="failed"
	data['method']="viewenquiry"
	return  demjson.encode(data)

@api.route('/message/',methods=['get','post'])
def message():
	data={}
	
	messages = request.args['messages']
	logid = request.args['logid']
	
	q = "insert into message values(null,(select parent_id from parents where log_id='%s'),'%s','pending',curdate())" % (logid,messages)
	login_id = insert(q)
	
	data['status'] = 'success'
	data['method']="message"
	return demjson.encode(data)

@api.route('/viewmessage/',methods=['get','post'])
def viewmessage():
	data={}
	logid=request.args['logid']
	
	q="select * from message where parent_id=(select parent_id from parents where log_id='%s')" %(logid)
	res=select(q)
	print(res)
	if res:
		data['status']="success"
		data['data']=res
	else:
		data['status']="failed"
	data['method']="viewmessage"
	return  demjson.encode(data)

@api.route('/viewdoctors/',methods=['get','post'])
def viewdoctors():
	data={}
	# logid=request.args['logid']
	
	q="select *,concat(fname,' ',lname) as name from doctors"
	res=select(q)
	print(res)
	if res:
		data['status']="success"
		data['data']=res
	else:
		data['status']="failed"
	data['method']="viewdoctors"
	return  demjson.encode(data)


@api.route('/viewchildss/',methods=['get','post'])
def viewchildss():
	data={}
	logid=request.args['lid']
	
	q="select * from child where parent_id=(select parent_id from parents where log_id='%s')" %(logid)
	res=select(q)
	print(res)
	if res:
		data['status']="success"
		data['data']=res
	else:
		data['status']="failed"
	data['method']="viewchildss"
	return  demjson.encode(data)


@api.route('/viewtask/',methods=['get','post'])
def viewtask():
	data={}
	logid=request.args['cid']
	
	q="select * from tasks inner join task_assign using(task_id) where child_id='%s'" %(logid)
	res=select(q)
	print(res)

	if res:
		data['status']="success"
		data['data']=res
	else:
		data['status']="failed"
	data['method']="viewtask"
	return  demjson.encode(data)

@api.route('/updatetaskperfomance/',methods=['get','post'])
def updatetaskperfomance():
	data={}
	
	assignid = request.args['assignid']
	perfomance = request.args['perfomance']
	q="select * from task_performance where assign_id='%s'" %(assignid)
	res=select(q)
	if res:
		q = "update task_performance set per_des='%s',per_date=curdate() where assign_id='%s'" %(perfomance,assignid)
		update(q)
	else:
		q = "insert into task_performance values(null,'%s','%s',curdate())" % (assignid,perfomance)
		insert(q)
	
	data['status'] = 'success'
	data['method']="updatetaskperfomance"
	return demjson.encode(data)


@api.route('/viewgame/',methods=['get','post'])
def viewgame():
	data={}
	logid=request.args['cid']
	
	q="select * from games inner join assign_games using(game_id) where child_id='%s'" %(logid)
	res=select(q)
	print(res)

	if res:
		data['status']="success"
		data['data']=res
	else:
		data['status']="failed"
	data['method']="viewgame"
	return  demjson.encode(data)


@api.route('/selectimages/',methods=['get','post'])
def selectimages():
	data={}
	gid=request.args['gid']
	
	q="select * from gameimage where game_id='%s'" %(gid)
	res=select(q)
	print(res)

	if res:
		data['status']="success"
		data['data']=res
	else:
		data['status']="failed"
	data['method']="selectimages"
	return  demjson.encode(data)


@api.route('/insertscore/',methods=['get','post'])
def insertscore():
	data={}
	
	assignid = request.args['assigndid']
	questions = request.args['questions']
	marks = request.args['marks']
	
	q = "insert into game_result values(null,'%s','%s','%s')" % (assignid,marks,questions)
	insert(q)
	
	data['status'] = 'success'
	data['method']="insertscore"
	return demjson.encode(data)